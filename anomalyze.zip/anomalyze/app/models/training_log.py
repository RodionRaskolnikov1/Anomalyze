import uuid
from sqlalchemy import Column, String, Integer, Float, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from app.db.database import Base


class ModelTrainingLog(Base):
    __tablename__ = "model_training_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # When the training job ran
    trained_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    # Outcome of this run
    status = Column(String, nullable=False)  # SUCCESS | SKIPPED | FAILED

    # How many IP records were in the training dataset
    # NULL when status=SKIPPED or FAILED (no dataset was built)
    sample_count = Column(Integer, nullable=True)

    # Number of features used
    feature_count = Column(Integer, nullable=True)

    # IsolationForest hyperparameters — useful when comparing runs
    contamination = Column(Float, nullable=True)
    n_estimators  = Column(Integer, nullable=True)
    training_days = Column(Integer, nullable=True)

    # How many anomalies the freshly trained model flagged when scored
    # against the training set. Should be close to contamination * sample_count.
    # Drift from this expectation signals the model needs attention.
    anomalies_on_train_set = Column(Integer, nullable=True)
    anomaly_rate           = Column(Float, nullable=True)   # anomalies / sample_count

    # Wall-clock training time in seconds
    elapsed_seconds = Column(Float, nullable=True)

    # Human-readable note — populated on SKIPPED/FAILED to explain why
    notes = Column(Text, nullable=True)